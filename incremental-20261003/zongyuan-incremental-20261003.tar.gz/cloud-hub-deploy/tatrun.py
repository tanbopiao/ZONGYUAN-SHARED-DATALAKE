#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""腾讯云 TAT 远程执行封装（TC3-HMAC-SHA256 直接签名，避开 SDK 字段 bug）。
用法: python3 tatrun.py '<shell命令>' [--timeout 60]
远程对 lhins-laotwc5e 执行命令并打印输出。
"""
import sys, time, json, hashlib, hmac, base64, urllib.request, urllib.parse

SECRET_ID = "AKIDStBpIakhS1QsBICwUp17KL998vUq0zqW"
SECRET_KEY = "gCbpsEf4KPLC2nOn3A6tWyHONQK6h8QX"
HOST = "tat.tencentcloudapi.com"
SERVICE = "tat"
REGION = "ap-shanghai"
VERSION = "2020-10-28"
ACTION = "RunCommand"

def sign_request(action, payload, instance_id="lhins-laotwc5e"):
    t = time.gmtime()
    timestamp = int(time.time())
    date = time.strftime("%Y-%m-%d", t)
    body = json.dumps(payload).encode()
    # Step1 规范请求串
    canonical_headers = f"content-type:application/json; charset=utf-8\nhost:{HOST}\nx-tc-action:{action.lower()}\n"
    signed_headers = "content-type;host;x-tc-action"
    hashed_payload = hashlib.sha256(body).hexdigest()
    canonical_request = "\n".join(["POST", "/", "", canonical_headers, signed_headers, hashed_payload])
    # Step2 待签字符串
    credential_scope = f"{date}/{SERVICE}/tc3_request"
    hashed_canonical = hashlib.sha256(canonical_request.encode()).hexdigest()
    string_to_sign = "\n".join(["TC3-HMAC-SHA256", str(timestamp), credential_scope, hashed_canonical])
    # Step3 派生密钥+签名
    def _hmac(key, msg):
        return hmac.new(key, msg.encode(), hashlib.sha256).digest()
    secret_date = _hmac(("TC3" + SECRET_KEY).encode(), date)
    secret_service = _hmac(secret_date, SERVICE)
    secret_signing = _hmac(secret_service, "tc3_request")
    signature = hmac.new(secret_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()
    # Step4 组装
    authorization = (f"TC3-HMAC-SHA256 Credential={SECRET_ID}/{credential_scope}, "
                     f"SignedHeaders={signed_headers}, Signature={signature}")
    headers = {
        "Authorization": authorization,
        "Content-Type": "application/json; charset=utf-8",
        "Host": HOST,
        "X-TC-Action": action,
        "X-TC-Timestamp": str(timestamp),
        "X-TC-Version": VERSION,
        "X-TC-Region": REGION,
    }
    req = urllib.request.Request(f"https://{HOST}/", data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())

def run_and_wait(cmd, timeout=120, name="zongyuan-deploy"):
    """创建命令→执行→轮询→返回输出"""
    import base64
    # 1 创建命令
    b64 = base64.b64encode(cmd.encode()).decode()
    try:
        c = sign_request("CreateCommand", {
            "CommandName": name, "CommandType": "SHELL",
            "Content": b64, "Timeout": timeout, "Username": "root",
            "Description": "ZONGYUAN auto deploy"})
        command_id = c["Response"]["CommandId"]
    except Exception as e:
        return f"CreateCommand失败: {e}"
    # 2 执行
    try:
        i = sign_request("InvokeCommand", {
            "CommandId": command_id, "InstanceIds": ["lhins-laotwc5e"]})
        inv_id = i["Response"]["InvocationId"]
    except Exception as e:
        return f"InvokeCommand失败: {e}"
    # 3 轮询：用 DescribeInvocations 定位 task id，再用 DescribeInvocationTasks 取输出
    task_id = None
    deadline = time.time() + timeout + 30
    while time.time() < deadline:
        time.sleep(6)
        try:
            if not task_id:
                dl = sign_request("DescribeInvocations", {"Limit": 6})
                for inv in dl["Response"].get("InvocationSet", []):
                    if inv.get("InvocationId") == inv_id:
                        tset = inv.get("InvocationTaskBasicInfoSet") or []
                        if tset and tset[0].get("InvocationTaskId"):
                            task_id = tset[0]["InvocationTaskId"]
                continue
            d = sign_request("DescribeInvocationTasks", {"InvocationTaskIds": [task_id]})
            tset = d["Response"].get("InvocationTaskSet", [])
            if not tset:
                continue
            resp = tset[0]
            status = resp.get("TaskStatus", "")
            if status == "SUCCESS":
                out = (resp.get("TaskResult") or {}).get("Output", "")
                try: out = base64.b64decode(out).decode()
                except: pass
                return out
            if status in ("FAILED", "TIMEOUT"):
                return f"[{status}] " + str((resp.get("TaskResult") or {}))[:500]
        except Exception as e:
            pass
    return "[TIMEOUT] 轮询超时"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: tatrun.py '<命令>' [--timeout N] [--name X]"); sys.exit(1)
    cmd = sys.argv[1]
    timeout = 120; name = "zongyuan-deploy"
    if "--timeout" in sys.argv: timeout = int(sys.argv[sys.argv.index("--timeout")+1])
    if "--name" in sys.argv: name = sys.argv[sys.argv.index("--name")+1]
    print(run_and_wait(cmd, timeout, name))
