#!/usr/bin/env bash
# ============================================================
#  云端中枢元内核 · WebShell 一键部署（阶段A）
#  用法: 复制整段到腾讯云控制台 WebShell 粘贴执行（root）
#  完成输出: 网关 /api/status + 真值上报 + 账本
#  官网镜像(594M)在阶段B单独恢复
#  DID-BR-000002 · Ω₀⊂⊙∞⊂Ω
# ============================================================
set -e
echo "========== [1/7] 环境自检 =========="
command -v python3 || { yum install -y -q python3 2>/dev/null || apt-get install -y -q python3 2>/dev/null; }
command -v git || { yum install -y -q git 2>/dev/null || apt-get install -y -q git 2>/dev/null; }
PY=$(command -v python3); echo "python3: $($PY -V 2>&1)"
git --version
# 宝塔存在性
BT=$(ls /www/server/panel 2>/dev/null && echo yes || echo no); echo "宝塔面板: $BT"

echo "========== [2/7] 建目录 =========="
mkdir -p /www/wwwroot/huodouai.com/zhongshu/data/truth
cd /www/wwwroot/huodouai.com/zhongshu

echo "========== [3/7] 拉取数据湖部署包 =========="
TOKEN=$(grep -h "MODELSCOPE_KEY=" /root/.zongyuan 2>/dev/null | cut -d= -f2-)
if [ -z "$TOKEN" ]; then
  # 未内置 token 时，走公开只读或提示输入
  echo "未找到内置数据湖token，请手动拉取:"
  echo "  git clone https://oauth2:<你的token>@modelscope.cn/datasets/zongyuanroot/ZONGYUAN-SHARED-DATALAKE.git /tmp/dlake"
  echo "  然后: cp -r /tmp/dlake/cloud-hub-deploy/zhongshu-server . && cp /tmp/dlake/cloud-hub-deploy/install.sh /tmp/dlake/cloud-hub-deploy/verify.sh ."
  exit 0
fi
git clone --depth 1 "https://oauth2:${TOKEN}@modelscope.cn/datasets/zongyuanroot/ZONGYUAN-SHARED-DATALAKE.git" /tmp/dlake 2>&1 | tail -2
cp -r /tmp/dlake/cloud-hub-deploy/zhongshu-server . 
cp /tmp/dlake/cloud-hub-deploy/install.sh /tmp/dlake/cloud-hub-deploy/verify.sh .
chmod +x verify.sh

echo "========== [4/7] 启动中枢三服务 =========="
bash zhongshu-server/run.sh start

echo "========== [5/7] 本地验证 =========="
bash verify.sh || echo "（部分项待Nginx对接后通过）"

echo "========== [6/7] 输出部署摘要 =========="
echo "--- 网关状态页 ---"
curl -s -m 5 http://127.0.0.1:9001/api/status || echo "网关未响应"
echo ""
echo "--- 真值上报测试 ---"
curl -s -m 5 -X POST http://127.0.0.1:9001/api/report/truth -H "X-DID: DID-BR-000002" -H "Content-Type: application/json" --data '{"key":"deploy.webshell","value":{"stage":"A","event":"中枢元内核部署"}}'
echo ""

echo "========== [7/7] 下一步 =========="
echo "✅ 中枢元内核已部署。请把以上完整输出复制发回给我。"
echo "阶段B: 官网镜像(594M)恢复 + Nginx公网对接，我随后指导。"
